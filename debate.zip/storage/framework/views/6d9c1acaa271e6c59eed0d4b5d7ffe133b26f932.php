 
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header"><?php echo e(__('Watch a Debate')); ?></div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('goforwatch')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <div class = "offset-md-1"> <strong> <?php echo e(__('Watch a Debate')); ?> </strong> </div>
                            <div class="form-group row">
                                <label for="watchDebateId" class="col-md-4 offset-md-1 col-form-label text-md-right"><?php echo e(__('Debate #:')); ?></label>
                                <div class="col-md-6">
                                    <input id="watchDebateId" type="text" placeholder = "<?php echo e(__('Your answer')); ?>" class="form-control<?php echo e($errors->has('watchDebateId') ? ' is-invalid' : ''); ?>" name="watchDebateId" >
                                    <?php if($errors->has('watchDebateId')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('watchDebateId')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="watchPassword" class="col-md-4 offset-md-1 col-form-label text-md-right"><?php echo e(__('Password:')); ?></label>
                                <div class="col-md-6">
                                    <input id="watchPassword" type="password" placeholder = "<?php echo e(__('Your answer')); ?>" class="form-control<?php echo e($errors->has('watchPassword') ? ' is-invalid' : ''); ?>" name="watchPassword" >

                                    <?php if($errors->has('watchPassword')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('watchPassword')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class = "form-group row">
                            <div class = "col-md-10 offset-md-1">
                                <div> <strong><?php echo e(__('Last Debate you watched:')); ?></strong> </div>
                                <div> Debate: <?php echo e($watchId); ?> </div>
                                <div class = "mb-30"> Topic: <?php echo e($watchTopic); ?> </div>

                                <div> <strong><?php echo e(__('Trending Debate Topics:')); ?></strong> </div>
                                <?php $__currentLoopData = $trendingDebate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $debate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div> - <?php echo e($debate->topic); ?> </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-3 text-md-center">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('SUBMIT')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header"><?php echo e(__('Join a Debate')); ?></div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('goforjoin')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class = "offset-md-1"> <strong> <?php echo e(__('Join a Debate')); ?> </strong> </div>
                        <div class="form-group row">
                            <label for="joinDebateId" class="col-md-4 offset-md-1 col-form-label text-md-right"><?php echo e(__('Debate #:')); ?></label>
                            <div class="col-md-6">
                                <input id="joinDebateId" type="text" placeholder = "<?php echo e(__('Your answer')); ?>" class="form-control<?php echo e($errors->has('joinDebateId') ? ' is-invalid' : ''); ?>" name="joinDebateId" >
                                <?php if($errors->has('joinDebateId')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('joinDebateId')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="joinPassword" class="col-md-4 offset-md-1 col-form-label text-md-right"><?php echo e(__('Password:')); ?></label>
                            <div class="col-md-6">
                                <input id="joinPassword" type="password" placeholder = "<?php echo e(__('Your answer')); ?>" class="form-control<?php echo e($errors->has('joinPassword') ? ' is-invalid' : ''); ?>" name="joinPassword" >
                                <?php if($errors->has('joinPassword')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('joinPassword')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class = "form-group row">
                            <div class = "col-md-10 offset-md-1">
                                <div> <strong><?php echo e(__('Last Debate you joined:')); ?></strong> </div>
                                <div> Debate: <?php echo e($joinId); ?> </div>
                                <div class = "mb-30"> Topic: <?php echo e($joinTopic); ?> </div>

                                <div> <strong><?php echo e(__('Most Popular Debate:')); ?></strong> </div>
                                <div> Debate: <?php echo e($topId); ?> </div>
                                <div class = "mb-30"> Topic: <?php echo e($topTopic); ?> </div>

                                <div> <strong><?php echo e(__('Fastest Growing Debate:')); ?></strong> </div>
                                <div> Debate: <?php echo e($growId); ?>  </div>
                                <div > Topic: <?php echo e($growTopic); ?> </div>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-3 text-md-center">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('SUBMIT')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/webrtc-adapter/6.4.0/adapter.min.js" ></script>
<script type="text/javascript" src="<?php echo e(asset('js/janus.js')); ?>" ></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.7.2/jquery.min.js" ></script>

<?php if(isset($_GET['alertType']) && $_GET['alertType'] == 1): ?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.3/toastr.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.3/toastr.css"/>
<script>
    $(document).ready(function() {
        toastr.warning('Please input correct Debate ID.');
    });
    window.history.pushState('Join', 'DebateFace', '/join');
</script>
<?php endif; ?>

<script>

var server = null;
if(window.location.protocol === 'http:')
    server = "http://" + window.location.hostname + ":8088/janus";
else
    server = "https://" + window.location.hostname + ":8089/janus";

var janus = null;
var sfutest = null;
var opaqueId = "listrequest-" + Janus.randomString(12);

$(document).ready(function() { 
    Janus.init({debug: "all", callback: function() { 
        janus = new Janus({
            server: server,
            success: function() {
                janus.attach({
                    plugin: "janus.plugin.videoroom",
                    opaqueId: opaqueId,
                    success: function(pluginHandle) {
                        sfutest = pluginHandle;
                        
                        var listCmd = { request: "list" };
                    
                        sfutest.send({"message": listCmd});
                        console.log(sfutest);
                    },
                    onmessage: function(msg, jsep) { 
                        console.log(msg);
                    }
                });
            },
            error: function(error) {
                console.log(error);
            },
            destroyed: function() {
                window.location.reload();
            }
        });
    }
    });
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>