 
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Browse/Join a Debate')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <div class = "col-md-6">
                                <div class = "offset-md-1"> <strong> <?php echo e(__('Watch a Debate')); ?> </strong> </div>
                                <div class="form-group row">
                                    <label for="watchDebateId" class="col-md-4 offset-md-1 col-form-label text-md-right"><?php echo e(__('Debate #:')); ?></label>
                                    <div class="col-md-6">
                                        <input id="watchDebateId" type="text" placeholder = "<?php echo e(__('Your answer')); ?>" class="form-control<?php echo e($errors->has('watchDebateId') ? ' is-invalid' : ''); ?>" name="watchDebateId" required>

                                        <?php if($errors->has('watchDebateId')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('watchDebateId')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="watchPassword" class="col-md-4 offset-md-1 col-form-label text-md-right"><?php echo e(__('Password:')); ?></label>
                                    <div class="col-md-6">
                                        <input id="watchPassword" type="password" placeholder = "<?php echo e(__('Your answer')); ?>" class="form-control<?php echo e($errors->has('watchPassword') ? ' is-invalid' : ''); ?>" name="watchPassword" required>

                                        <?php if($errors->has('watchPassword')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('watchPassword')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class = "offset-md-1"> <strong> <?php echo e(__('Join a Debate')); ?> </strong> </div>
                                <div class="form-group row">
                                    <label for="joinDebateId" class="col-md-4 offset-md-1 col-form-label text-md-right"><?php echo e(__('Debate #:')); ?></label>
                                    <div class="col-md-6">
                                        <input id="joinDebateId" type="text" placeholder = "<?php echo e(__('Your answer')); ?>" class="form-control<?php echo e($errors->has('joinDebateId') ? ' is-invalid' : ''); ?>" name="joinDebateId" required>

                                        <?php if($errors->has('joinDebateId')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('joinDebateId')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="joinPassword" class="col-md-4 offset-md-1 col-form-label text-md-right"><?php echo e(__('Password:')); ?></label>
                                    <div class="col-md-6">
                                        <input id="joinPassword" type="password" placeholder = "<?php echo e(__('Your answer')); ?>" class="form-control<?php echo e($errors->has('joinPassword') ? ' is-invalid' : ''); ?>" name="joinPassword" required>

                                        <?php if($errors->has('joinPassword')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('joinPassword')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class = "col-md-6">
                                <div class = "form-group row">
                                    <div class = "col-md-10 offset-md-1">
                                        <div> <strong><?php echo e(__('Last Debate you watched:')); ?></strong> </div>
                                        <div> Debate: 9538 </div>
                                        <div class = "mb-30"> Topic: Chocolate or Vanilla </div>

                                        <div> <strong><?php echo e(__('Trending Debate Topics:')); ?></strong> </div>
                                        <div> 1. Is Tom brady the best QB? </div>
                                        <div> 2. Will Trump Win 2020 Election? </div>
                                        <div> 3. Will the healthcare bill pass? </div>
                                        <div> 4. Who's more powerful JLo or Arod? </div>
                                        <div> 5. What's better for you? Tea vs Coffee </div>
                                    </div>
                                </div>
                            </div>
                            <div class = "col-md-6">
                                <div class = "form-group row">
                                    <div class = "col-md-10 offset-md-1">
                                        <div> <strong><?php echo e(__('Last Debate you joined:')); ?></strong> </div>
                                        <div> Debate: 5136 </div>
                                        <div class = "mb-30"> Who's better? Mets or Rays </div>

                                        <div> <strong><?php echo e(__('Most Popular Debate:')); ?></strong> </div>
                                        <div> Debate: 6234 </div>
                                        <div class = "mb-30"> Should the US invade Iran </div>

                                        <div> <strong><?php echo e(__('Fastest Growing Debate:')); ?></strong> </div>
                                        <div> Debate: 1791 </div>
                                        <div > MJ was the king, not Elvis </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-3 text-md-center">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('SUBMIT')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>