 
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Start a Debate')); ?></div>

                <div class="card-body">
                    <form method="POST" id="gostartForm" action="<?php echo e(route('gostart')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="email" class="col-md-5 col-form-label text-md-right"><?php echo e(__('Topic of your Debate ?')); ?></label>

                            <div class="col-md-6">
                                <input id="topic" type="text" placeholder = "<?php echo e(__('Your answer')); ?>" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="topic" value="<?php echo e(old('email')); ?>" required autofocus>

                                <?php if($errors->has('topic')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('topic')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-5 col-form-label text-md-right"><?php echo e(__('Public or Private ?')); ?></label>

                            <div class="col-md-6 ">
                                <div class="form-check">
                                    <div>
                                        <input class="form-check-input" type="radio" name="debatetype" id="publictype" value = "0" checked>

                                        <label class="form-check-label" for="publictype">
                                            <?php echo e(__('Public')); ?>

                                        </label>
                                    </div>
                                    <div>
                                        <input class="form-check-input" type="radio" name="debatetype" id="privatetype" value = "1" >

                                        <label class="form-check-label" for="privatetype">
                                            <?php echo e(__('Private')); ?>

                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-5 col-form-label text-md-right"><?php echo e(__('Password of Debate')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="text" placeholder = "<?php echo e(__('Your Password')); ?>" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" >

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="rule" class="col-md-5 col-form-label text-md-right"><?php echo e(__('Rules or Instructions')); ?></label>

                            <div class="col-md-6">
                                <input id="rule" type="text" placeholder = "<?php echo e(__('Your answer')); ?>" class="form-control<?php echo e($errors->has('rule') ? ' is-invalid' : ''); ?>" name="rule" >

                                <?php if($errors->has('rule')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('rule')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="invite" class="col-md-5 col-form-label text-md-right"><?php echo e(__('Invite User 1 email :')); ?></label>

                            <div class="col-md-6">
                                <input id="debator_one" type="text" placeholder = "<?php echo e(__('debator Email')); ?>" class="form-control<?php echo e($errors->has('debator_one') ? ' is-invalid' : ''); ?>" name="debator_one" >

                                <?php if($errors->has('debator_one')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('debator_one')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="invite" class="col-md-5 col-form-label text-md-right"><?php echo e(__('Invite User 2 email :')); ?></label>

                            <div class="col-md-6">
                                <input id="debator_two" type="text" placeholder = "<?php echo e(__('debator Email')); ?>" class="form-control<?php echo e($errors->has('debator_two') ? ' is-invalid' : ''); ?>" name="debator_two" >

                                <?php if($errors->has('debator_two')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('debator_two')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-5">
                                <button type="submit" class="btn btn-primary" id = "submitBtn">
                                    <?php echo e(__('SUBMIT')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
// $(function() {
    // $('#submitBtn').click(function() {
    //     var debateData = {
    //         topic: $("input[name=debatetype]").val(),
    //         debatetype: $("input[name=debatetype]")[0].checked ? "0" : "1",
    //         password: $("input[name=password]").val()
    //     };
    //     if( $("input[name=rule]").val() != '' )
    //         $debateData['rule'] = $("input[name=rule]").val();
    //     if( $("input[name=debator_one]").val() != '' )
    //         $debateData['debator_one'] = $("input[name=debator_one]").val();
    //     if( $("input[name=debator_two]").val() != '' )
    //         $debateData['debator_two'] = $("input[name=debator_two]").val();

    //     $.ajax({
    //         type: 'POST',
    //         url: "<?php echo e(route('gostart')); ?>",
    //         data: debateData,
    //         error: function()
    //         {
    //             alert("Request Failed");
    //         },
    //         success: function(response)
    //         {  
    //             if( response == 'noauth' )
    //             {
                    
    //             }
    //         }
    //     });
    //     return false;
    // }); 
// });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>